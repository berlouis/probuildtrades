import dynamic from "next/dynamic";

const CMSPageEditor = dynamic(
  () => import("@/components/admin/pages/CMSPageEditor"),
  { ssr: false }
);

export default CMSPageEditor;
