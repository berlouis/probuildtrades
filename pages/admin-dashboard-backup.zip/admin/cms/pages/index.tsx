import dynamic from "next/dynamic";

const CMSPagesPage = dynamic(
  () => import("@/components/admin/pages/CMSPagesPage"),
  { ssr: false }
);

export default CMSPagesPage;
