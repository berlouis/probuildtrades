export default function DocumentsPage() {
  return <div>Documents Page</div>;
}
