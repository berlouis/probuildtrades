export default function FlaggedPage() {
  return <div>Flagged Page</div>;
}
