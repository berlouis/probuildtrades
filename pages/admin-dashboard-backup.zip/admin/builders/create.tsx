import dynamic from "next/dynamic";

const BuilderCreatePage = dynamic(
  () => import("@/components/admin/pages/BuilderCreatePage"),
  { ssr: false }
);

export default BuilderCreatePage;
