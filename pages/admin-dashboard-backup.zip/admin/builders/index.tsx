import dynamic from "next/dynamic";

const BuilderListPage = dynamic(
  () => import("@/components/admin/pages/BuilderListPage"),
  { ssr: false }
);

export default BuilderListPage;
