import Link from 'next/link';

export default function BuildersPage() {
  return (
    <div style={{ padding: '2rem' }}>
      <h1>Builder Dashboard</h1>
      <p>Manage registered builders here.</p>
      <Link href="/admin/builders/create">
        <button style={{ marginTop: '1rem' }}>+ Create New Builder</button>
      </Link>
    </div>
  );
}

import Link from 'next/link';

function BuildersPage() {
  return (
    <div style={{ padding: '2rem' }}>
      <h1>Builders</h1>
      <Link href="/admin/builders/create">
        <button style={{ marginTop: '1rem' }}>Create New Builder</button>
      </Link>
    </div>
  );
}

export default BuildersPage;
