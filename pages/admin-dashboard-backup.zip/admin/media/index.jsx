import { useState, useEffect } from 'react'
import AdminLayout from '@/components/admin/AdminLayout'

export default function MediaLibraryPage() {
  const [media, setMedia] = useState<string[]>([])
  const [file, setFile] = useState<File | null>(null)

  useEffect(() => {
    fetch('/uploads')
      .then(res => res.json())
      .then(data => setMedia(data.files))
  }, [])

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!file) return
    const formData = new FormData()
    formData.append('file', file)

    const res = await fetch('/api/admin/media/upload', {
      method: 'POST',
      body: formData,
    })

    const data = await res.json()
    if (data.url) {
      setMedia(prev => [...prev, data.url])
    }
  }

  return (
    <AdminLayout title="Media Library">
      <h1 className="text-2xl font-bold mb-4">Media Library</h1>

      <form onSubmit={handleUpload} className="mb-8">
        <input
          type="file"
          accept="image/*"
          onChange={e => setFile(e.target.files?.[0] || null)}
          className="mb-2"
        />
        <button type="submit" className="bg-blue-500 text-white px-4 py-2 rounded">
          Upload
        </button>
      </form>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {media.map((url, idx) => (
          <div key={idx}>
            <img src={url} alt="Uploaded" className="w-full rounded" />
          </div>
        ))}
      </div>
    </AdminLayout>
  )
}
