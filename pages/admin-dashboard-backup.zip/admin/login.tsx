import dynamic from "next/dynamic";

const AdminLoginPage = dynamic(
  () => import("@/components/admin/pages/AdminLoginPage"),
  { ssr: false }
);

export default AdminLoginPage;
