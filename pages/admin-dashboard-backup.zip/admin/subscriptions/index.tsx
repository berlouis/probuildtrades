import dynamic from "next/dynamic";

const AdminSubscriptionsPage = dynamic(
  () => import("@/components/admin/pages/AdminSubscriptionsPage"),
  { ssr: false }
);

export default AdminSubscriptionsPage;
